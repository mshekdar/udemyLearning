var myApp = angular.module('myApp', []);

myApp.controller('mainController', function($scope) {
	$scope.name = 'Mayuresh'
    console.log($scope)
});	