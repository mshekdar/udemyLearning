var learningApp = angular.module('learningApp',[]);

learningApp.controller('Controller1',function(){
	
});